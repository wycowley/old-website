import java.util.ArrayList;
public class PredictOutcome{
    public void predict(ArrayList<AI> aiSnakes, Snake snake, Fruit currentFruit, int frames){
        for(int i = 0;i<aiSnakes.size();i++){
            int fruitX = currentFruit.getX();
            int fruitY = currentFruit.getY();
            int x2 = aiSnakes.get(i).getX();
            int y2 = aiSnakes.get(i).getY();

            if(fruitY>Math.round(y2)){
                aiSnakes.get(i).setDirection(4);
            }else if(fruitY<Math.round(y2)){
                aiSnakes.get(i).setDirection(2);
            }else if(fruitX>Math.round(x2)){
                aiSnakes.get(i).setDirection(1);
            }else if(fruitX<Math.round(x2)){
                aiSnakes.get(i).setDirection(3);
            }
            if(fruitX>Math.round(x2) && fruitY<Math.round(y2)){
                aiSnakes.get(i).setDirection(1);
                if(aiSnakes.get(i).checkPotential(aiSnakes.get(i).getX()+10,aiSnakes.get(i).getY())){
                    aiSnakes.get(i).setDirection(2);
                }
            }else if(fruitX<Math.round(x2) && fruitY<Math.round(y2)){
                aiSnakes.get(i).setDirection(3);
                if(aiSnakes.get(i).checkPotential(aiSnakes.get(i).getX()-10,aiSnakes.get(i).getY())){
                    aiSnakes.get(i).setDirection(2);
                }
            }else if(fruitX>Math.round(x2) && fruitY>Math.round(y2)){
                aiSnakes.get(i).setDirection(1);
                if(aiSnakes.get(i).checkPotential(aiSnakes.get(i).getX()+10,aiSnakes.get(i).getY())){
                    aiSnakes.get(i).setDirection(4);
                }
            }else if(fruitX<Math.round(x2) && fruitY>Math.round(y2)){
                aiSnakes.get(i).setDirection(3);
                if(aiSnakes.get(i).checkPotential(aiSnakes.get(i).getX()-10,aiSnakes.get(i).getY())){
                    aiSnakes.get(i).setDirection(4);
                }
            }else{
                if(fruitY>Math.round(y2)){
                    aiSnakes.get(i).setDirection(4);
                }else if(fruitY<Math.round(y2)){
                    aiSnakes.get(i).setDirection(2);
                }else if(fruitX>Math.round(x2)){
                    aiSnakes.get(i).setDirection(1);
                }else if(fruitX<Math.round(x2)){
                    aiSnakes.get(i).setDirection(3);
                }
            }

            for(int k = 0;k<aiSnakes.size();k++){
                if(k==i)
                    k++;
                if(k==aiSnakes.size())
                    break;
                for(int j = 0;j<3;j++){
                    if(aiSnakes.get(i).getDirection()==1){
                        int posX = aiSnakes.get(i).getX()+10;
                        int posY = aiSnakes.get(i).getY();
                        if(aiSnakes.get(i).checkPotentialAll(aiSnakes.get(k).getPastX(),aiSnakes.get(k).getPastY(),posX,posY)){
                            aiSnakes.get(i).setDirection((aiSnakes.get(i).getDirection()+1));
                        }
                    } if(aiSnakes.get(i).getDirection()==2){
                        int posX = aiSnakes.get(i).getX();
                        int posY = aiSnakes.get(i).getY()-10;
                        if(aiSnakes.get(i).checkPotentialAll(aiSnakes.get(k).getPastX(),aiSnakes.get(k).getPastY(),posX,posY)){
                            aiSnakes.get(i).setDirection((aiSnakes.get(i).getDirection()+1));
                            


                        }
                    } if(aiSnakes.get(i).getDirection()==3){
                        int posX = aiSnakes.get(i).getX()-10;
                        int posY = aiSnakes.get(i).getY();
                        if(aiSnakes.get(i).checkPotentialAll(aiSnakes.get(k).getPastX(),aiSnakes.get(k).getPastY(),posX,posY)){
                            aiSnakes.get(i).setDirection((aiSnakes.get(i).getDirection()+1));
                            

                        }
                    } if(aiSnakes.get(i).getDirection()==4){
                        int posX = aiSnakes.get(i).getX();
                        int posY = aiSnakes.get(i).getY()+10;
                        if(aiSnakes.get(i).checkPotentialAll(aiSnakes.get(k).getPastX(),aiSnakes.get(k).getPastY(),posX,posY)){
                            aiSnakes.get(i).setDirection((aiSnakes.get(i).getDirection()+1));
                            


                        }
                    }
                }
            }
            

            for(int k = 0;k<6;k++){
                int direction = aiSnakes.get(i).getDirection();
                ArrayList<Integer> pastX = snake.getPastX();
                ArrayList<Integer> pastY = snake.getPastY();
                int x = aiSnakes.get(i).getX();
                int y = aiSnakes.get(i).getY();
                if(direction==1){
                    if(checkPotential(x+10,y, pastX, pastY)){
                        aiSnakes.get(i).setDirection(direction+1);
                    }
                }else if(direction==2){
                    if(checkPotential(x,y-10, pastX, pastY)){
                        aiSnakes.get(i).setDirection(direction+1);

                    }
                }else if(direction==3){
                    if(checkPotential(x-10,y, pastX, pastY)){
                        aiSnakes.get(i).setDirection(direction+1);

                    }
                }else if(direction==4){
                    if(checkPotential(x,y+10, pastX, pastY)){
                        aiSnakes.get(i).setDirection(direction+1);

                    }
                }
            }

        }
        for(AI each: aiSnakes){
            if(frames%2 == 1){
                each.moveForNextTurn();
            }
        }
    }
    private boolean checkPotential(int x, int y, ArrayList<Integer> pastX, ArrayList<Integer> pastY){
        for(int i = 0;i<pastX.size();i++){
            if(Math.round(pastX.get(i))==Math.round(x) && Math.round(pastY.get(i))==Math.round(y)){
                return true;
            }
        }
        return false;
    }
}