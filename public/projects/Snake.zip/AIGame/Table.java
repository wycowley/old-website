import java.awt.Graphics;
import java.awt.Color;
import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.geom.Line2D;
import java.awt.Graphics2D;
import java.awt.Font;
import java.awt.BasicStroke;

public class Table extends JPanel implements KeyListener, MouseListener{
    private double forSin;
    private Snake snake;
    private Fruit fruit;
    private boolean playing = false;
    private boolean settingsMenu;


    private Color black = new Color(0,0,0);
    private Color white = new Color(255,255,255);
    private Color beautifulColor = new Color(255, 203, 199);
    private Font big = new Font("Sans-Serif",Font.PLAIN,25);
    private Font realBig = new Font("Sans-Serif",Font.PLAIN,45);

    private ArrayList<ScoreEntry> scores = new ArrayList<ScoreEntry>();
    private ArrayList<AI> aiSnakeList;
    private PredictOutcome p = new PredictOutcome();


    private boolean goodForMovingAgain = true;
    private int frames;
    private boolean add = true;
    private boolean scoresMenu = false;
    private int score = 0;
    private int difficulty = 1;

    public Table(){
        aiSnakeList = new ArrayList<AI>();
        snake = new Snake(250,200);
        fruit = new Fruit((int)(Math.random()*50)*10,(int)(Math.random()*40)*10);
        setFocusable(true);
        addKeyListener(this);
        addMouseListener(this);

    }
    public Dimension getPreferredSize() {
        return new Dimension(500,400);
    }
    public void paintComponent(Graphics g){
        g.setColor(white);
        g.fillRect(0,0,1000,800);

        if(playing){
            g.setColor(black);
            g.drawString("Score: "+score,25,25);
            g.drawString("Difficulty: "+difficulty,25,37);

            fruit.drawMe(g);
            for(int i = 0;i<aiSnakeList.size();i++){
                aiSnakeList.get(i).drawMe(g,fruit);
            }

            outer: for(int i = 0;i<aiSnakeList.size();i++){
                if(fruit.checkCollision(aiSnakeList.get(i).getX(),aiSnakeList.get(i).getY())){
                    aiSnakeList.get(i).addSegment(g);
                    fruit = new Fruit((int)(Math.random()*50)*10,(int)(Math.random()*40)*10);

                }
                if(aiSnakeList.get(i).getDeath()){
                    aiSnakeList.remove(i);
                    score++;
                    i--;
                    break;
                }
                for(int k = 0;k<aiSnakeList.size();k++){
                    if(k==i)
                        k++;
                    if(k==aiSnakeList.size())
                        break;
                    if(aiSnakeList.get(i).checkAll(aiSnakeList.get(k).getPastX(),aiSnakeList.get(k).getPastY())){
                        aiSnakeList.remove(i);
                        score++;
                        break outer;
                    }
                }
                aiSnakeList.get(i).checkIfSnake(snake.getPastX(), snake.getPastY());
                
            }
            if(difficulty<3){
                p.predict(aiSnakeList, snake, fruit, frames);
            }else{
                p.predict(aiSnakeList, snake, fruit, 1);
            }

            if(snake.drawMe(g)){
                playing = false;
                if(scores!=null){                    
                    scores.add(0,new ScoreEntry(score,difficulty));
                }else
                    scores.add(new ScoreEntry(score,difficulty));
                aiSnakeList.clear();
            }
            for(int i = 0;i<aiSnakeList.size();i++){
                if(snake.checkAll(aiSnakeList.get(i).getPastX(),aiSnakeList.get(i).getPastY())){
                    playing = false;
                    if(scores!=null){                    
                        scores.add(0,new ScoreEntry(score,difficulty));
                    }else
                        scores.add(new ScoreEntry(score,difficulty));

                    aiSnakeList.clear();
                    break;
                }
            }
            goodForMovingAgain = true;
            if(fruit.checkCollision(snake.getX(),snake.getY())){
                snake.addSegment(g);
                fruit = new Fruit((int)(Math.random()*50)*10,(int)(Math.random()*40)*10);
                score++;
                if(difficulty == 2||difficulty==3){
                    if(add){
                        aiSnakeList.add(new AI((int)(Math.random()*50)*10,(int)(Math.random()*40)*10));
                        add = false;
                    }else
                        add = true; 
                }
                if(difficulty == 1){
                    if(aiSnakeList.size()!=1){
                        aiSnakeList.add(new AI((int)(Math.random()*50)*10,(int)(Math.random()*40)*10));
                    }
                }
                if(difficulty == 4){
                    aiSnakeList.add(new AI((int)(Math.random()*50)*10,(int)(Math.random()*40)*10));
                }
            }
            
        }else{
            if(!settingsMenu&&!scoresMenu)
                drawMenu(g);
            else{
                if(settingsMenu)
                    drawSettings(g);
                else
                    drawScores(g);
            }

        }
        
    }
    private void drawSettings(Graphics g){
        g.setColor(beautifulColor);
        g.fillRect(0,0,500,400);
        g.setColor(white);
        fillPrettyBox(g,50,50,350,150,25);
        g.fillOval(25,325,50,50);
        g.setColor(black);
        drawPrettyBox(g,35,345,25,15,5);

        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        g2.draw(new Line2D.Float(40, 345, 50, 337));
        g2.draw(new Line2D.Float(50, 337, 60, 345));
        g.setColor(new Color(230,230,230));
        g.fillRect(176+32*difficulty,120,30,50);
        g.setColor(black);
        g.setFont(big);
        g.drawString("Difficulty:  1  2  3  4",80,150);
    }
    private void drawScores(Graphics g){
        g.setColor(beautifulColor);
        g.fillRect(0,0,500,400);
        g.setColor(white);
        g.fillOval(25,325,50,50);
        g.setColor(black);
        drawPrettyBox(g,35,345,25,15,5);

        Graphics2D g2 = (Graphics2D) g;
        g2.setStroke(new BasicStroke(5));
        g2.draw(new Line2D.Float(40, 345, 50, 337));
        g2.draw(new Line2D.Float(50, 337, 60, 345));
        g.setColor(new Color(230,230,230));

        g.setFont(big);
        if(scores.size()>0 && scores.size()<8){
            for(int i = 0;i<scores.size();i++){
                g.setColor(white);
                fillPrettyBox(g, 90, i*50+20, 330, 40, 7);
                g.setColor(black);
                g.drawString(scores.get(i).get(),100,i*50+50);
            }
        }else if (scores.size()==0){
            g.setColor(white);
                fillPrettyBox(g, 90, 20, 330, 40, 7);
                g.setColor(black);
                g.drawString("Play to get scores!",100,50);
        }else{
            for(int i = 0;i<7;i++){
                g.setColor(white);
                fillPrettyBox(g, 90, i*50+20, 330, 40, 7);
                g.setColor(black);
                g.drawString(scores.get(i).get(),100,i*50+50);
            }
        }

    }

    private void drawPrettyBox(Graphics g, int x, int y, int width, int height, int ovalWidth){
        g.fillOval(x,y,ovalWidth,ovalWidth);
        g.fillOval(x+width,y,ovalWidth,ovalWidth);
        g.fillOval(x,y+height,ovalWidth,ovalWidth);
        g.fillOval(x+width,y+height,ovalWidth,ovalWidth);
        g.fillRect(x+ovalWidth/2,y,width,ovalWidth);
        g.fillRect(x+ovalWidth/2,y+height,width,ovalWidth);
        g.fillRect(x,y+ovalWidth/2,ovalWidth,height);
        g.fillRect(x+width,y+ovalWidth/2,ovalWidth,height);
    }
    private void fillPrettyBox(Graphics g, int x, int y, int width, int height, int ovalWidth){
        g.fillOval(x,y,ovalWidth,ovalWidth);
        g.fillOval(x+width,y,ovalWidth,ovalWidth);
        g.fillOval(x,y+height,ovalWidth,ovalWidth);
        g.fillOval(x+width,y+height,ovalWidth,ovalWidth);
        g.fillRect(x+ovalWidth/2,y,width,ovalWidth);
        g.fillRect(x+ovalWidth/2,y+height,width,ovalWidth);
        g.fillRect(x,y+ovalWidth/2,ovalWidth,height);
        g.fillRect(x+width,y+ovalWidth/2,ovalWidth,height);
        g.fillRect(x+ovalWidth,y+ovalWidth,width-ovalWidth,height-ovalWidth);

    }

    private void drawMenu(Graphics g){
        g.setColor(beautifulColor);
        g.fillRect(0,0,500,400);
        forSin+=.025;
        g.setColor(white);
        fillPrettyBox(g,190,30,135,50,15);
        g.setColor(black);
        g.setFont(realBig);
        g.drawString("Snake",200,75);

        g.setFont(big);
        g.setColor(white);
        g.fillRect(150,165+(int)(Math.sin(forSin)*50),200,60);
        g.fillOval(120,165+(int)(Math.sin(forSin)*50),60,60);
        g.fillOval(320,165+(int)(Math.sin(forSin)*50),60,60);

        g.setColor(Color.BLACK);
        g.drawString("New Game",185,205+(int)(Math.sin(forSin)*50));

        

        g.setColor(white);
        g.fillOval(85,325,50,50);
        
        g.setColor(black);

        int[] xPoints1 = {105,97,101,109};
        int[] yPoints1 = {350,360,364,354};
        g.fillPolygon(xPoints1,yPoints1,4);
        int[] xPoints2 = {93+20,99+20,103+20,96+20};
        int[] yPoints2 = {354,364,360,350};
        g.fillPolygon(xPoints2,yPoints2,4);

        g.setColor(black);
        g.fillOval(97,335,26,26);
        g.setColor(white);
        g.fillOval(102,340,16,16);


        //ALL FOR SETTING ICON
        g.setColor(white);
        g.fillOval(25,325,50,50);
        g.setColor(Color.BLACK);
        int[] xPoints = new int[32];
        int[] yPoints = new int[32];

        for(int i = 0;i<xPoints.length;i++){
            if(i%4==1 || i%4==2){
                xPoints[i] = (int)(Math.sin((i*360/32.0)/180.0*3.14)*20)+50;
                yPoints[i] = (int)(Math.cos((i*360/32.0)/180.0*3.14)*20)+350;
            }else{
                xPoints[i] = (int)(Math.sin((i*360/32.0)/180.0*3.14)*15)+50;
                yPoints[i] = (int)(Math.cos((i*360/32.0)/180.0*3.14)*15)+350;
            }
        }
        g.fillPolygon(xPoints,yPoints,32);
        g.setColor(white);
        g.fillOval(40,340,20,20);
    }


    public void animate(){
        while(true){
            try {

                if(snake.getSize()<25){
                    Thread.sleep(100-snake.getSize()*2);
                }else{
                    Thread.sleep(50);
                }
            }catch(InterruptedException ex) {
                Thread.currentThread().interrupt();
            }
            frames++;
            repaint();
        }
    }
    public void keyPressed(KeyEvent e){
        // System.out.println(e.getKeyCode());
        if(goodForMovingAgain){
            if(e.getKeyCode()==37 || e.getKeyCode()==65){
                snake.setDirection(3);
            }else if(e.getKeyCode()==38 || e.getKeyCode()==87){
                snake.setDirection(2);
            }else if(e.getKeyCode()==68 || e.getKeyCode()==39){
                snake.setDirection(1);
            }else if(e.getKeyCode()==40 || e.getKeyCode()==83){
                snake.setDirection(4);
            } 
            goodForMovingAgain = false;
        }
    }

    public void mousePressed(MouseEvent e){
        if(!playing && !settingsMenu && between(120,350,150,280,e.getX(),e.getY())){
            playing=true;
            score = 0;
            snake = new Snake(250,200);
            aiSnakeList.add(new AI(0,400));
            fruit = new Fruit((int)(Math.random()*50)*10,(int)(Math.random()*40)*10);
        }
        if(between(25,75,325,375,e.getX(),e.getY())){
            if(settingsMenu || scoresMenu){
                settingsMenu = false;
                scoresMenu = false;
            }else{
                settingsMenu = true;
            }
        }
        if(between(85,135,325,375,e.getX(),e.getY())&&!scoresMenu){
            scoresMenu = true;
        }
        if(settingsMenu){
            
            if(between(176+32,176+32*2,120,170,e.getX(),e.getY())){
                difficulty = 1;
            }else if(between(176+32*2,176+(32*3),120,170,e.getX(),e.getY())){
                difficulty = 2;
            }else if(between(176+(32*3),176+(32*4),120,170,e.getX(),e.getY())){
                difficulty = 3;
            }else if(between(176+(32*4),176+(32*5),120,170,e.getX(),e.getY())){
                difficulty = 4;
            }
        }
    }
    private boolean between(int x1, int x2, int y1, int y2, int posX, int posY){
        if(posX>x1&&posX<x2&&posY>y1&&posY<y2){
            return true;
        }
        return false;
    }

    public void mouseEntered(MouseEvent e){ }
    public void mouseReleased(MouseEvent e){ }
    public void mouseClicked(MouseEvent e){ }
    public void mouseExited(MouseEvent e){ }

    public void keyReleased(KeyEvent e){}
    public void keyTyped(KeyEvent e){}
}