import java.awt.Graphics;
import java.awt.Color;
public class Fruit{
    private int x;
    private int y;
    private Color beautyful = new Color(252, 212, 101);
    public Fruit(int x, int y){
        this.x = x;
        this.y = y;
    }
    public void drawMe(Graphics g){
        
        g.setColor(beautyful);
        g.fillOval(x,y,10,10);
        g.setColor(Color.BLACK);
        g.drawOval(x,y,10,10);
    }
    public Boolean checkCollision(int snakeX, int snakeY){
        if(Math.round(snakeX)==Math.round(x)&&Math.round(snakeY)==Math.round(y)){
            return true;
        }
        return false;
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
}