import java.awt.Graphics;
import java.awt.Color;

import java.util.ArrayList;
public class AI{
    private int x;
    private int y;
    private ArrayList<Integer> pastX = new ArrayList<Integer> ();
    private ArrayList<Integer> pastY = new ArrayList<Integer> ();
    private int direction=1;
    private Color green = new Color(150,50,75);
    private Color darkGreen = new Color(75,25,25);
    private Fruit currentFruit;
    private boolean visible;
    private boolean death;

    public AI(int x, int y){
        this.x = x;
        this.y = y;
        for(int i = 1;i<11;i++){
            pastX.add(x-10*(10-i));
            pastY.add(y);

        }
    }
    public void drawMe(Graphics g, Fruit fruit){
        currentFruit = fruit;
        for(int i = 0;i<pastX.size();i++){
            green = new Color(150+(int)(Math.sin(i/180.0*3.14*3)*50),25,59);
            g.setColor(green);
            g.fillOval(pastX.get(i),pastY.get(i),10,10);

            if(i!=0){
                if(pastX.get(i)>pastX.get(i-1))
                    g.fillOval(pastX.get(i)-5,pastY.get(i),10,10);
                else if(pastX.get(i)<pastX.get(i-1))
                   g.fillOval(pastX.get(i)+5,pastY.get(i),10,10);
                else if(pastY.get(i)<pastY.get(i-1))
                   g.fillOval(pastX.get(i),pastY.get(i)+5,10,10);
                else if(pastY.get(i)>pastY.get(i-1))
                   g.fillOval(pastX.get(i),pastY.get(i)-5,10,10);
            }
        }
        
        g.setColor(darkGreen);
        g.fillOval(x,y,10,10);
        
        
        

    }
    public void moveForNextTurn(){
        for(int i = 0;i<5;i++){
            if(direction==1){
                if(checkPotential(x+10,y)){
                    direction++;
                }
            }
            if(direction==2){
                if(checkPotential(x,y-10)){
                    direction++;
                }
            }
            if(direction==3){
                if(checkPotential(x-10,y)){
                    direction++;
                }
            }
            if(direction==4){
                if(checkPotential(x,y+10)){
                    direction=1;
                }
            }
        }

        if(direction==1){x+=10;}
        if(direction==2){y-=10;}
        if(direction==3){x-=10;}
        if(direction==4){y+=10;}
        if(x>490){x=0;}
        if(0>x){x=490;}
        if(y>390){y=0;}
        if(0>y){y=390;}

        pastX.add(x);
        pastY.add(y);
        pastX.remove(0);
        pastY.remove(0);

        checkIfCollided();
        
    }
    

    private void checkIfCollided(){
        for(int i = 0;i<pastX.size()-1;i++){
            if(Math.round(pastX.get(i))==Math.round(pastX.get(pastX.size()-1)) && Math.round(pastY.get(i))==Math.round(pastY.get(pastX.size()-1))){
                death = true;
                break;
            }
        }
    }
    public void checkIfSnake(ArrayList<Integer> pastX, ArrayList<Integer> pastY){
        for(int i = 0;i<pastX.size();i++){
            if(Math.round(pastX.get(i))==Math.round(x) && Math.round(pastY.get(i))==Math.round(y)){
                death = true;
                break;
            }
        }
    }
    public boolean checkPotential(int x, int y){
        for(int i = 0;i<pastX.size()-1;i++){
            if(Math.round(pastX.get(i))==Math.round(x) && Math.round(pastY.get(i))==Math.round(y)){
                return true;
            }
        }
        return false;
    }
    public void addSegment(Graphics g){
        pastX.add(1,pastX.get(0));
        pastY.add(1,pastY.get(0));
        drawMe(g, currentFruit);
    }
    
    public boolean checkAll(ArrayList<Integer> xP, ArrayList<Integer> yP){
        for(int i = 0;i<xP.size()-1;i++){
            if(Math.round(xP.get(i))==Math.round(x) && Math.round(yP.get(i))==Math.round(y)){
                return true;
            }
        }
        return false;
    }
    public boolean checkPotentialAll(ArrayList<Integer> xP, ArrayList<Integer> yP, int x2, int y2){
        for(int i = 0;i<xP.size()-1;i++){
            if(Math.round(xP.get(i))==Math.round(x2) && Math.round(yP.get(i))==Math.round(y2)){
                return true;
            }
        }
        return false;
    }

    public ArrayList<Integer> getPastX(){
        return pastX;
    }
    public ArrayList<Integer> getPastY(){
        return pastY;
    }
    public boolean getDeath(){
        return death;
    }
    public int getDirection(){
        return direction;
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
    public int getSize(){
        return pastX.size();
    }
    public void setDirection(int direction){
        if(this.direction+2!=direction && this.direction!=direction+2){
            this.direction = direction;
        }
        if(direction==5){
            this.direction = 1;
        }
    }
}