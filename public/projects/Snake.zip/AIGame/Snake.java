import java.awt.Graphics;
import java.awt.Color;

import java.util.ArrayList;
public class Snake{
    private int x;
    private int y;
    private ArrayList<Integer> pastX = new ArrayList<Integer> ();
    private ArrayList<Integer> pastY = new ArrayList<Integer> ();
    private int direction=1;
    private Color green = new Color(50,150,50);
    private Color darkGreen = new Color(25,75,25);


    public Snake(int x, int y){
        this.x = x;
        this.y = y;
        for(int i = 1;i<11;i++){
            pastX.add(x-10*(10-i));
            pastY.add(y);

        }
    }
    public boolean drawMe(Graphics g){
        
        
        for(int i = 0;i<pastX.size();i++){
            green = new Color(50,150+(int)(Math.sin(i/180.0*3.14*3)*50),50);
            g.setColor(green);
            g.fillOval(pastX.get(i),pastY.get(i),10,10);

            if(i!=0){
                if(pastX.get(i)>pastX.get(i-1))
                    g.fillOval(pastX.get(i)-5,pastY.get(i),10,10);
                else if(pastX.get(i)<pastX.get(i-1))
                   g.fillOval(pastX.get(i)+5,pastY.get(i),10,10);
                else if(pastY.get(i)<pastY.get(i-1))
                   g.fillOval(pastX.get(i),pastY.get(i)+5,10,10);
                else if(pastY.get(i)>pastY.get(i-1))
                   g.fillOval(pastX.get(i),pastY.get(i)-5,10,10);
            }
        }
        g.setColor(darkGreen);
        g.fillOval(x,y,10,10);
        
        
        
        if(moveForNextTurn())
            return true;
        return false;

    }
    private boolean moveForNextTurn(){
        if(direction==1){x+=10;}
        if(direction==2){y-=10;}
        if(direction==3){x-=10;}
        if(direction==4){y+=10;}
        if(x>490){x=0;}
        if(0>x){x=490;}
        if(y>390){y=0;}
        if(0>y){y=390;}

        pastX.add(x);
        pastY.add(y);
        pastX.remove(0);
        pastY.remove(0);

        if(checkIfCollided())
            return true;
        return false;
    }
    public void setDirection(int direction){
        if(this.direction+2!=direction && this.direction!=direction+2){
            this.direction = direction;
        }
    }

    private boolean checkIfCollided(){
        for(int i = 0;i<pastX.size()-1;i++){
            if(Math.round(pastX.get(i))==Math.round(x) && Math.round(pastY.get(i))==Math.round(y)){
                return true;
            }
        }
        return false;
    }
    public boolean checkAll(ArrayList<Integer> xP, ArrayList<Integer> yP){
        for(int i = 0;i<xP.size()-1;i++){
            if(Math.round(xP.get(i))==Math.round(x) && Math.round(yP.get(i))==Math.round(y)){
                return true;
            }
        }
        return false;
    }
    public int getX(){
        return x;
    }
    public int getY(){
        return y;
    }
    public void addSegment(Graphics g){
        pastX.add(1,pastX.get(0));
        pastY.add(1,pastY.get(0));
        drawMe(g);
    }
    public int getSize(){
        return pastX.size();
    }
    public ArrayList<Integer> getPastX(){
        return pastX;
    }
    public ArrayList<Integer> getPastY(){
        return pastY;
    }
}