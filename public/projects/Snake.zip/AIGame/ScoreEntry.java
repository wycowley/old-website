public class ScoreEntry{
    private int value;
    private int difficulty;
    public ScoreEntry(int value, int difficulty){
        this.value = value;
        this.difficulty = difficulty;
    }
    public String get(){
        return "Score: "+value+", Difficulty: "+difficulty;
    }
}